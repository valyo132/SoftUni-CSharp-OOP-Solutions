﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StackOfStrings
{
    public class StackOfStrings : Stack<string>
    {
        public bool IsEmpty()
        {
            if (Count == 0)
                return true;

            return false;
        }

        public Stack<string> AddRange(params string[] words)
        {
            foreach (var item in words)
            {
                Push(item);
            }

            return this;
        }
    }
}
