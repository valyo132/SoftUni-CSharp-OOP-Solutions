﻿namespace CollectionHierarchy.Interfaces
{
    public interface IRemove : IAdd
    {
        public string RemoveItem();
    }
}
