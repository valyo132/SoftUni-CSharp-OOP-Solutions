﻿namespace CollectionHierarchy.Interfaces
{
    public interface IMyList : IRemove
    {
        public int Used { get; }
    }
}
