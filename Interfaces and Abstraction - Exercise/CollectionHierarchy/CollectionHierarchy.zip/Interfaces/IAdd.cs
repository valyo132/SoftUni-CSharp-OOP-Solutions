﻿namespace CollectionHierarchy.Interfaces
{
    public interface IAdd
    {
        public int Add(string item);
    }
}
