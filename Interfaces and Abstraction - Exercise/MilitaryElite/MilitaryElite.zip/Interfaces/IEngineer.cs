﻿namespace MilitaryElite.Interfaces
{
    using System.Collections.Generic;

    public interface IEngineer
    {
        public List<Repair> Repairs { get; set; }
    }
}
