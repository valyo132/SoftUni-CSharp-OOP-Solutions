﻿namespace MilitaryElite.Interfaces
{
    using System.Collections.Generic;

    public interface ILieutenantGeneral
    {
        public List<Private> Privates { get; set; }
    }
}
