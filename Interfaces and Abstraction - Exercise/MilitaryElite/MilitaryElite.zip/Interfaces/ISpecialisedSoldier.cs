﻿namespace MilitaryElite.Interfaces
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get; set; }
    }
}
