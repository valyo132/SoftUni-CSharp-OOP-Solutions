﻿namespace Telephony.NewFolder
{
    public interface ICallable
    {
        public void Call(string number);
    }
}
