﻿namespace Telephony.NewFolder
{
    public interface ISmartphonealbe
    {
        public void Browse(string link);
    }
}
