﻿namespace BirthdayCelebrations
{
    public interface IIdentifiable
    {
        public string Name { get; set; }
        public string Id { get; set; }
    }
}
